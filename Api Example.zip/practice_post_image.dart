import 'dart:io';
import 'package:api_project/pin_controller.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:shared_preferences/shared_preferences.dart';
import 'pin_screen.dart';

class PracticePostImage extends StatefulWidget {
  const PracticePostImage({super.key});

  @override
  State<PracticePostImage> createState() => _PracticePostImageState();
}

class _PracticePostImageState extends State<PracticePostImage> {
  File? image;
  final ImagePicker _picker = ImagePicker();
  List<String> imagePaths = [];
  bool isPinVerified = false;

  @override
  void initState() {
    super.initState();
    _loadImagePaths();
  }

  Future<String> get _imageDirectory async {
    final directory = await getApplicationDocumentsDirectory();
    final imageDirectory = Directory(path.join(directory.path, 'images'));
    if (!await imageDirectory.exists()) {
      await imageDirectory.create(recursive: true);
    }
    return imageDirectory.path;
  }

  Future<void> getImage() async {
    final pickedImage = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      final directoryPath = await _imageDirectory;
      final fileName = path.basename(pickedImage.path);
      final newPath = path.join(directoryPath, fileName);
      final newImage = await File(pickedImage.path).copy(newPath);

      setState(() {
        image = newImage;
        imagePaths.add(newImage.path);
      });

      _saveImagePaths();
    } else {
      print('No image selected');
    }
  }

  Future<void> _loadImagePaths() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      imagePaths = prefs.getStringList('imagePaths') ?? [];
    });
  }

  Future<void> _saveImagePaths() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setStringList('imagePaths', imagePaths);
  }

  void _verifyPin() {
    setState(() {
      isPinVerified = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isPinVerified
        ? Scaffold(
      appBar: AppBar(
        title: Text('Upload Image'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: GestureDetector(
              onTap: getImage,
              child: Container(
                height: 40,
                width: 110,
                decoration: BoxDecoration(
                  color: Colors.deepPurple,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    'Pick Image',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 20), // Add some space between the button and the image
          if (image != null)
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
              ),
              child: Image.file(
                image!.absolute,
                height: 300,
                width: 200,
                fit: BoxFit.cover,
              ),
            ),
          SizedBox(height: 20),
          Text(
            'Saved Images:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: GridView.builder(
              itemCount: imagePaths.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: AspectRatio(
                    aspectRatio: 1, // Adjust the aspect ratio as needed
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.file(
                        File(imagePaths[index]),
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                );
              }, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4),
            ),
          ),

        ],
      ),
    )
        : PinScreen(onPinEntered: (pin) {
      _verifyPin();
    });
  }
}
