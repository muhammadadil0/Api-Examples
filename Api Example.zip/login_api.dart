import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';
class LoginApi extends StatefulWidget {
  const LoginApi({super.key});

  @override
  State<LoginApi> createState() => _LoginApiState();
}

class _LoginApiState extends State<LoginApi> {
  TextEditingController emailController  = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  void login(String email,String password)async{
    try{
      Response response = await post(
        Uri.parse('https://reqres.in/api/register'),
        body: {
          'email':email,
          "password":password
        }
      );
      var data = jsonDecode(response.body.toString());
      if(response.statusCode==200){
        print('account created successfully');
      }
      else{
        print('failed');
    }
      
    }
    catch(e){
      print(e.toString());
    }
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text('Login using Api'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFormField(
              controller: emailController,
              decoration:  InputDecoration(
                hintText: "Enter the email",

                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                enabled: true,


              ),

            ),
            SizedBox(
              height: 20,
            ),
            TextFormField(
              controller: passwordController,
              decoration:  InputDecoration(
                hintText: "Enter the password",

                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                enabled: true,
             

              ),

            ),
            SizedBox(
              height: 20,
            ),
            GestureDetector(
              onTap: ()=>login(emailController.text,passwordController.text),
              child: Container(
                height: 40,
                width: 80,

                decoration: BoxDecoration(
                  color: Colors.deepPurple,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: Text('Sign in',style: TextStyle(color: Colors.white),)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
