import 'dart:convert';
import 'package:api_project/user_Model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart'as http;
class ExampleFour extends StatefulWidget {
  const ExampleFour({super.key});

  @override
  State<ExampleFour> createState() => _ExampleFourState();
}

class _ExampleFourState extends State<ExampleFour> {
  var data;
  List<UserModel> userList = [];
  Future<void> getUserApi()async{
    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/users'));
    if(response.statusCode==200){
      var data = jsonDecode(response.body.toString());
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fetch Api'),
      ),
      body:
        Column(
          children: [
            Expanded(child: FutureBuilder(
              future: getUserApi(),
              builder: (context,snapshot){
                if(snapshot.connectionState==ConnectionState.waiting)
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                else{
                  return Text(data[0]['name'].toString());
                }

              },
            ))
          ],
        ),

    ) ;
  }
}
