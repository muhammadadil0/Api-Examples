import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ExampleTwo extends StatefulWidget {
  const ExampleTwo({super.key});

  @override
  State<ExampleTwo> createState() => _ExampleTwoState();
}

class _ExampleTwoState extends State<ExampleTwo> {
  List<Photos> photoList = [];

  Future<List<Photos>> getPhotoApi() async {
    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/photos'));
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body) as List;
      for (Map<String, dynamic> i in data) {
        Photos photo = Photos(title: i['title'], url: i['url']);
        photoList.add(photo);
      }
      return photoList;
    } else {
      return photoList;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('API Example'),
      ),
      body: Column(
        children: [
          FutureBuilder(future: getPhotoApi(), builder: (context,AsyncSnapshot<List<Photos>>snapshot){
            if(snapshot.connectionState==ConnectionState.waiting){
              return CircularProgressIndicator();
            }
            else if(snapshot.hasError){
              return Text('Error');
            }
            else if(!snapshot.hasData || snapshot.data!.isEmpty){
              return Text('NO Photos is Available');
            }
            else{
              return ListView.builder(
                  itemCount: photoList.length,
                  itemBuilder: (context,index){
                    return ListTile(
                      title: Text(photoList[index].title),
                      leading: Image.network(photoList[index].url),
                    );
                  });
            }
          })
        ],
      ),
    );
  }
}

class Photos {
  String title, url;
  Photos({required this.title, required this.url});
}
