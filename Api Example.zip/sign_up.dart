import 'dart:convert';

import'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  void login(String email, String password)async{
 try{
   Response response = await post(
    Uri.parse('https://reqres.in/api/register'),
     body: {
      'email': email,
      'password':password,
     }
   ) as http.Response;
   if(response.statusCode==200){
     var data = jsonDecode(response.body.toString());

     print(data);
     print('account created successfully');
   }
   else{
     print('failed');
   }
 }
 catch(e){
   print(e.toString());
 }
  }
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("Login Using API"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
             TextFormField(
               controller: emailController,
               decoration: InputDecoration(
                 hintText: "Enter the email",

               ),

             ),
            SizedBox(height: 20,),
            TextFormField(
               controller: passwordController,
               decoration: InputDecoration(
                 hintText: "Enter the password",

               ),

             ),
            SizedBox(height: 40,),
            GestureDetector(
              onTap: (){
                login(emailController.text.toString(),passwordController.text.toString());
              },

              child: Container(
                width: 80,
                height: 40,
                child: Center(
                  child: Text('Sign in'),
                ),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
