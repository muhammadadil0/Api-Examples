import 'package:flutter/material.dart';

class PinScreen extends StatefulWidget {
  final Function(String) onPinEntered;

  const PinScreen({required this.onPinEntered, Key? key}) : super(key: key);

  @override
  _PinScreenState createState() => _PinScreenState();
}

class _PinScreenState extends State<PinScreen> {
  final TextEditingController _pinController = TextEditingController();
  final String correctPin = "1234"; // Hardcoded for simplicity

  void _checkPin() {
    if (_pinController.text == correctPin) {
      widget.onPinEntered(_pinController.text);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Incorrect PIN'),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Enter PIN')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _pinController,
              keyboardType: TextInputType.number,
              obscureText: true,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'PIN',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _checkPin,
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
