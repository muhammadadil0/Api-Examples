import 'package:flutter/material.dart';

class TimePicker extends StatefulWidget {
  const TimePicker({super.key});

  @override
  State<TimePicker> createState() => _TimePickerState();
}

class _TimePickerState extends State<TimePicker> {
  TimeOfDay selectedTime = TimeOfDay.now();
  Future<void> _selectedTime(BuildContext context)async{
    final TimeOfDay? picked = await showTimePicker(
        context: context,

        initialTime: selectedTime,
    );

    if(picked!=null && picked!=selectedTime)
      setState(() {
        selectedTime = picked;
      });

  }
  DateTime date = DateTime.now();
  Future<void> _pickedDate(BuildContext context)async{
    final DateTime? pickedDate = await showDatePicker(

        context: context,

        firstDate: DateTime(2000), lastDate: DateTime(2101));
    if(pickedDate!=null && pickedDate!=date)
      setState(() {
        date = pickedDate;
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Time Picker'),
      ),
      body: Column(
        children: [
          Center(
            child: GestureDetector(
              onTap: () => _selectedTime(context),
              child: Container(
                height: 50,
                width: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      blurRadius: 7,
                      spreadRadius: 5,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Center(
                      child: Text(
                        'Picked Time',
                        style: TextStyle(color: Colors.black),
                      ),
                    ),

                  ],
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: ()=>_pickedDate(context),
            child: Center(
              child: Text(
                'Picked Date',
                style: TextStyle(color: Colors.black),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

