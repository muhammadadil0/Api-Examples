import 'dart:io';

import 'package:flutter/material.dart';

import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

class GetImage extends StatefulWidget {
  const GetImage({super.key});

  @override
  State<GetImage> createState() => _GetImageState();
}

class _GetImageState extends State<GetImage> {
  File? image;
  final _picker = ImagePicker();
   bool showSpinner = false;
  Future getImage() async {
    final pickFile = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 100,
    );
    if (pickFile != null) {
      setState(() {
        image = File(pickFile.path);
      });
    } else {
      print('No image selected');
    }
  }
  Future <void> uploadImage()async{
    setState(() {
      showSpinner = true;
    });
   var stream = new http.ByteStream(image!.openRead());
   stream.cast();
   var length = await image!.length();
   var uri = Uri.parse('https://fakestoreapi.com/products');
   var request = http.MultipartRequest('POST',uri);
   var multiport = http.MultipartFile(
     'image',
     stream,
     length,
   );
    request.files.add(multiport);
    var response = await request.send();
    if(response.statusCode==200){
      setState(() {
        showSpinner = false;
      });
      print('image is uploaded');
    }
    else{
      print('failed');
      setState(() {
        showSpinner = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return  ModalProgressHUD(

      inAsyncCall: showSpinner,
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: getImage,
              child: Container(
                  child: image==null? Center(child: Text('Pick Image'),):
                  Container(
                    child: Center(
                      child: Image.file(
                        File(image!.path).absolute,
                        height: 100,
                        width: 100,
                        fit: BoxFit.cover,
                      ),
                    ),

                  )
              ),
            ),
            SizedBox(height: 40,),
            GestureDetector(
              onTap: uploadImage,
              child:   Container(
                child: Center(
                  child: Text('upload image'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
